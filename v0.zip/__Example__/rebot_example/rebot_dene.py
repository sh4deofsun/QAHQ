from robot import rebot

with open("__Example__/rebot_example/output.xml", "rb") as file:
    rebot(file, outputdir="__Example__/rebot_example/Result", output="output.xml")