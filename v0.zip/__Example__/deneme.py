# Deneme

from fastapi import FastAPI, File, UploadFile, Request
from fastapi.responses import JSONResponse
from typing import Annotated
import time

app = FastAPI()

@app.middleware(["http", "https"])
async def process_time_middleware(request: Request, call_next):
    start_time = time.perf_counter()
    response = await call_next(request)
    process_time = time.perf_counter() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    response.headers["Server"] = "FileUpload-Service"
    return response

@app.post("/upload/")
async def upload_file(file: Annotated[UploadFile | None, File()] = None):
    if not file:
        return JSONResponse(
            status_code=400,
            content={"message": "No file was uploaded"}
        )
    
    try:
        contents = await file.read()
        # Here you could add file processing logic
        
        return JSONResponse(
            status_code=200,
            content={
                "filename": file.filename,
                "content_type": file.content_type,
                "file_size": len(contents)
            }
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"message": f"An error occurred: {str(e)}"}
        )

