import requests

# Define the URL to which the file will be uploaded
url = 'http://localhost:8000/get_test_count/'

# Specify the path to the file you want to upload
file_path = '__Example__/test_example/Result/output.xml'

# Open the file in binary mode and send it in a POST request
with open(file_path, 'rb') as file:
    # The 'files' parameter is a dictionary where the key is the field name
    # expected by the server and the value is a tuple containing the file name
    # and the file object
    files = {'file': (file_path, file)}
    
    # Send the POST request
    response = requests.post(url, files=files, timeout=30)

# Check the response from the server
if response.status_code == 200:
    print(f"File uploaded successfully! {response.json()}")
else:
    print('Failed to upload file. Status code:', response.status_code)
