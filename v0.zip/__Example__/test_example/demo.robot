*** Test Cases ***
Test Case That Passes
    [Documentation]    This test case will always pass
    [Tags]    test1    PASS
    Should Be Equal    1    1

Test Case That Fails
    [Documentation]    This test case will always fail
    [Tags]    test2    FAIL
    Should Be Equal    1    2
